/* 3-a) Complete la función controlHijos, de modo que: 
si está tildado el elemento con id 'lblHijos', agregue en el section de id="hijos" 
un input de tipo number, sino no debe estar ese input. 
No modificar nada en el archivo index.html donde se encuentra el formulario.
El código a agregar es: <input type="number" id="hijos" name="cantHijos">
*/

function controlHijos (event) {
    /* completar */


}

/* 3-b) b.	Agregue al checkbox un 'escuchador' de eventos, 
que cuando se produzca el evento change, reaccione con la función controlHijos. */