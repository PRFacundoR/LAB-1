/*
Al hacer click en el botón de la página simulación.html, se deberá activar 
una función de nombre simular, que se encontrará en el archivo funciones.js, 
en la carpeta js, cuya tarea será ingresar mediante estructura iterativa 
y un prompt, tareas pendientes, que se irán agregando 
como li dentro del ul con id pendientes, 
debiendo finalizar cuando se ingrese sólo una letra "x". 
*/


function simular () 
{

}