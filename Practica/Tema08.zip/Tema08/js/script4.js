
/* 3-a) Complete la función mostrarImagen, de modo que: 
Sólo si el género elegido es Ciencia Ficción, es decir, scifi, muestre 
en el article con id="sugerencia" la imagen de Star Trek, sino no muestre nada. 
(el article debe quedar vacío en ese caso). 
No modificar nada en el archivo index.html donde se encuentra el formulario.
Código a agregar: 
<img src="img/startrek.jpg" alt="Mujer vestida de rojo atrás de la silla de capitán">
*/

function mostrarImagen (event) {
    
    /* completar */



}

/* 3-b) Agregue al formulario de id miFormu un 'escuchador' de eventos, 
que cuando se produzca el evento submit, reaccione con la función mostrarImagen */

