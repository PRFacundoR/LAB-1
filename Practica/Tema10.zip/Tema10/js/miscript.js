/*
5.	(2,50) Al hacer mousedown en el botón de la página simulación.html, 
se deberá activar una función de nombre simular, que se encontrará en el 
archivo miscript.js, en la carpeta js, cuya tarea será ingresar mediante un prompt, 
el valor de las compras que se van haciendo durante el viaje. 
Cuando la suma supere los 900000 deberá detenerse, 
mostrar dentro de la página (no con ventana) el total gastado 
y además cuál fue el valor que tuvo el gasto de mayor valor.
*/

function simular () 
{
    
}