/* 
5. Al hacer click en el botón de la página simulación.html, 
se deberá activar una función de nombre simular, que estará en
 el archivo funciones3.js, cuya tarea será pedir un número 
 de tabla de multiplicar mediante un prompt, y luego mostrar 
 en distintos párrafos, los valores de 
 multiplicar tabla por 0, por 1, …, hasta 10.

*/