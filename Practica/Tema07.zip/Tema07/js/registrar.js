/*
4) Trabaje en el archivo registrar.js, dentro de la carpeta js, que servirá 
para que el formulario de la página anterior funcione, y complete de modo que:
a.	Al intentar hacer el envío del formulario (submit), 
se invoque a una función de nombre verificar, cuya tarea será controlar que 
la longitud de los input de clave y clave repetida tengan una longitud mayor a 4 
(no verificar otras cosas),
sino mostrar en la página, en el párrafo con id mensaje, el texto "La clave y 
la repetición de clave deben tener al menos 4 caracteres".
*/

function verificar (event) 
{
    
}